package da6;

public class Welcome {

	public static void main(String[] args) {
		System.out.println("Welcome to World of Java");

	}

}
